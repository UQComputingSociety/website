import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class LawnMower {

	public static void main(String[] args) throws IOException{
		String fileInPath = "lawnmower.in";
		String fileOutPath = "lmOut.txt";
		
		if (args.length>=1) {
			fileInPath = args[0];			
		}
		if (args.length>=2) {
			fileOutPath = args[1];
		}
		
		Scanner sc = new Scanner(new FileReader(fileInPath));
		FileWriter fOut = new FileWriter(fileOutPath);
		
		
		int numCases = sc.nextInt();
		for (int caseNo=1; caseNo<=numCases; caseNo++){
			boolean possible = true;
		
			//Solve the problem!
		
			
			String canString = possible ? "YES" : "NO";
			fOut.write("Case #"+caseNo+": "+canString+'\n');
		}
		
		
		
		sc.close();
		fOut.close();
		System.out.println("Done!");
	}
	
}
