import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class LawnMower {

	public static void main(String[] args) throws IOException{
		String fileInPath = "lawnmower.in";
		String fileOutPath = "lmOut.txt";
		
		if (args.length>=1) {
			fileInPath = args[0];			
		}
		if (args.length>=2) {
			fileOutPath = args[1];
		}
		
		Scanner sc = new Scanner(new FileReader(fileInPath));
		FileWriter fOut = new FileWriter(fileOutPath);
		
		
		int numCases = sc.nextInt();
		for (int caseNo=1; caseNo<=numCases; caseNo++){
			int N = sc.nextInt();
			int M = sc.nextInt();
			
			/** The patern of grass we desire, in mm */
			int[][] desired = new int[N][M];
			for(int i=0; i<N;i++){
				for (int j=0; j<M; j++){
					//Read in the values
					desired[i][j] = sc.nextInt();
				}
			}
			
			/*
			 * Visual representation of the grass
			 * M (indexed by i) x N (indexed by j)
			 *
			 *   --m--(i)
			 * [][][][]  |
			 * [][][][]  n
			 * [][][][]  |
			 *          (j)
			 */
			
			
			//Time to solve the question: Can we cut the pattern?
			//Lets see how low we could safely cut the grass, without disrupting any pattern by cutting too low.
			
			/** An array storing the lowest possible height we could cut each grass square */
			int[][] lowestPossible  = new int[N][M]; 
			for(int i=0; i<N;i++){
				for (int j=0; j<M; j++){
					lowestPossible[i][j] = 100;
				}
			}
			
			//Cut by Column
			//For each row
			for(int i=0; i<N; i++){
				//Determine what height we could send our lawnmower 'down' at
				int minAllowableCut = -1;
				for (int j=0; j<M; j++) {
					minAllowableCut = Math.max(minAllowableCut, desired[i][j]);
				}
				//Set that to be the lowest possible, if this cut makes it lower (will always in this case)
				for (int j=0; j<M; j++) {
					lowestPossible[i][j] = Math.min(lowestPossible[i][j],minAllowableCut);
				}
			}
			
			//Cut by Row
			//For each column
			for(int j=0; j<M; j++){
				//Determine what height we could send our lawnmower 'across' at
				int minAllowableCut = -1;
				for (int i=0; i<N; i++) {
					minAllowableCut = Math.max(minAllowableCut, desired[i][j]);
				}
				//Set that to be the lowest possible, if this cut makes it lower
				for (int i=0; i<N; i++) {
					lowestPossible[i][j] = Math.min(lowestPossible[i][j],minAllowableCut);
				}
			}
			
			
			//Assess if possible
			boolean possible = true;
			for(int j=0; j<M; j++){
				for (int i=0; i<N; i++) {
					possible &= lowestPossible[i][j] <= desired[i][j]; //Test whether we can cut that square as low as we desire
									//equality test actually works as well
				}
			}
			String canString = possible ? "YES" : "NO";
			fOut.write("Case #"+caseNo+": "+canString+'\n');
		}
		
		
		
		sc.close();
		fOut.close();
		System.out.println("Done!");
	}
	
}
